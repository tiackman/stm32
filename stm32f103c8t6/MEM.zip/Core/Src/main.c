/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdlib.h>
#include <string.h>
#include "retarget.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {
    /* USER CODE BEGIN 1 */
    //全局区
    int q1;        //未初始化全局变量
    static int q2;        //未初始化静态变量
    const int q3;        //未初始化只读变量

    int m1 = 1;        //已初始化全局变量
    static int m2 = 2;        //已初始化静态变量

    //常量区
    const int m3 = 3;        //已初始化只读变量
    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_USART1_UART_Init();
    /* USER CODE BEGIN 2 */
    RetargetInit(&huart1);
    printf("\r\nMemory\r\n");
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1) {
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
        //栈区
        int mq1;            //未初始化局部变量
        int *mq2;            //未初始化局部指针变量

        int mq3 = 3;        //已初始化局部变量
        char qq[10] = "hello"; //已初始化局部数组

        const int mq4;            //未初始化局部只读变量
        const int mq5 = 3;        //已初始化局部只读变量

        //堆区
        int *p1 = malloc(4);    //已初始化局部指针变量p1
        int *p2 = malloc(4);    //已初始化局部指针变量p2

        //全局区
        static int mp1;            //未初始化局部静态变量
        static int mp2 = 2;        //已初始化局部静态变量

        //常量区
        char *vv = "I LOVE YOU";//已初始化局部指针变量
        char *mq = "5201314";

        printf("============================\r\n", main);

        printf("\n栈区-变量地址\n");
        printf("未初始化局部变量 		:0x%p\r\n", &mq1);
        printf("未初始化局部指针变量		:0x%p\r\n", &mq2);
        printf("已初始化局部变量			:0x%p\r\n", &mq3);
        printf("已初始化局部数组			:0x%p\r\n", qq);

        printf("未初始化局部只读变量 		:0x%p\r\n", &mq4);
        printf("已初始化局部只读变量		:0x%p\r\n", &mq5);

        printf("\n堆区-动态申请地址\r\n");
        printf("已初始化局部int型指针变量p1   :0x%p\r\n", p1);
        printf("已初始化局部int型指针变量p2   :0x%p\r\n", p2);

        printf("\n全局区-变量地址\n");
        printf("未初始化全局变量 	:0x%p\r\n", &q1);
        printf("未初始化静态变量		:0x%p\r\n", &q2);
        printf("未初始化只读变量		:0x%p\r\n", &q3);

        printf("已初始化全局变量 	:0x%p\r\n", &m1);
        printf("已初始化静态变量		:0x%p\r\n", &m2);

        printf("未初始化局部静态变量	 :0x%p\r\n", &mp1);
        printf("已初始化局部静态变量	 :0x%p\r\n", &mp2);

        printf("\n常量区地址\n");
        printf("已初始化只读变量		  :0x%p\r\n", &m3);
        printf("已初始化局部指针变量	  :0x%p\r\n", vv);
        printf("已初始化局部指针变量	  :0x%p\r\n", mq);

        printf("\n代码区地址\n");
        printf("程序代码区main函数入口地址	:0x%p\n", main);

        HAL_GPIO_TogglePin(LED0_GPIO_Port, LED0_Pin);
        HAL_Delay(1000);

        free(p1);
        free(p2);
    }
    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                  | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void) {
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1) {
//测试
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
